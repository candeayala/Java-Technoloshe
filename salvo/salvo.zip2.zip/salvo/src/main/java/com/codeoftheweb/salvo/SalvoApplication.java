package com.codeoftheweb.salvo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

import java.util.Date;

@SpringBootApplication
public class SalvoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalvoApplication.class, args);
	}

	@Bean
	public CommandLineRunner initData(PlayerRepository repository, GameRepository gameRepository) {
		return (args) -> {
			// save a couple of customers
			repository.save(new Player("candela.Ayala116@Gmail.com"));
			repository.save(new Player("Maria_Flores@Yahoo.com"));
			repository.save(new Player("Sarita_y_Franco@Hotmail.com"));
			repository.save(new Player("Daniel992@Gmail.com"));
			repository.save(new Player("Michelle_Obama@Gmail.com"));

			Game game1 = new Game();
			game1.setCreationDate(new Date());
			Game game2 = new Game();
			game2.setCreationDate(new Date());
			Game game3 = new Game();
			game3.setCreationDate(new Date());

		};
	}

}

