package com.codeoftheweb.salvo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SpringBootApplication
public class SalvoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalvoApplication.class, args);
	}

	@Bean
	public CommandLineRunner initData(PlayerRepository playerRepository, GameRepository gameRepository, GamePlayerRepository gamePlayerRepository, ShipRepository shipRepository, SalvoRepository salvoRepository) {
		return (args) -> {
			// save a couple of PLAYERS
			Player player1 = new Player("j.bauer@ctu.gov");
			Player player2 = new Player("c.obrian@ctu.gov");
			Player player3 = new Player("kim_bauer@gmail.com");
			Player player4 = new Player("t.almeida@ctu.gov");
			Player player5 = new Player("d.palmer@whitehouse.gov");
			playerRepository.save(player1);
			playerRepository.save(player2);
			playerRepository.save(player3);
			playerRepository.save(player4);


			/*Player player1= new Player("Cande");
			Player player2= new Player("Crash");
			Player player3= new Player("Bomberman");
			playerRepository.save(new Player("candela.Ayala116@Gmail.com"));
			playerRepository.save(new Player("Maria_Flores@Yahoo.com"));
			playerRepository.save(new Player("Sarita_y_Franco@Hotmail.com"));
			playerRepository.save(new Player("Daniel992@Gmail.com"));
			playerRepository.save(new Player("Michelle_Obama@Gmail.com"));
			playerRepository.save(player1);
			playerRepository.save(player2);
			playerRepository.save(player3);*/

			Date date = new Date();
			Date date2 = Date.from(date.toInstant().plusSeconds(3600));
			Date date3 = Date.from(date.toInstant().plusSeconds(7200));

			Game game1 = new Game(date);
			Game game2 = new Game(date2);
			Game game3 = new Game(date3);


			gameRepository.save(game1);
			gameRepository.save(game2);
			gameRepository.save(game3);

			GamePlayer gamePlayer1 = new GamePlayer(game1, player1, date);
			GamePlayer gamePlayer2 = new GamePlayer(game1, player2, date);
			GamePlayer gamePlayer3 = new GamePlayer(game2, player3, date2);
			GamePlayer gamePlayer4 = new GamePlayer(game2, player4, date2);


			gamePlayerRepository.save(gamePlayer1);
			gamePlayerRepository.save(gamePlayer2);
			gamePlayerRepository.save(gamePlayer3);

			List<String> locations1 = new ArrayList<>();
			locations1.add("H1");
			locations1.add("H3");
			locations1.add("H4");

			List<String> locations2 = new ArrayList<>();
			locations2.add("A2");
			locations2.add("A3");
			locations2.add("A4");

			List<String> locations3 = new ArrayList<>();
			locations3.add("B5");
			locations3.add("C5");
			locations3.add("D5");

			/*String shipType1 = "Carrier";
			String shipType2 = "BattleShip";
			String shipType3 = "Submarine";
			String shipType4 = "Destroyer";
			String shipType5 = "PatrolBoat";*/

			Ship shipType1= new Ship("Destroyer", locations1, gamePlayer1);
			Ship shipType2= new Ship("Battleship", locations3, gamePlayer1);
			Ship shipType3= new Ship("Submarine", locations2, gamePlayer1);
			Ship shipType4= new Ship("Destroyer", locations1, gamePlayer2);
			Ship shipType5= new Ship("PatrolBoat", locations2, gamePlayer2);

			shipRepository.save(shipType1);
			shipRepository.save(shipType2);
			shipRepository.save(shipType3);
			shipRepository.save(shipType4);
			shipRepository.save(shipType5);

			List<String> salvoLoc1 = new ArrayList<>();
			salvoLoc1.add("B5");
			salvoLoc1.add("C5");
			salvoLoc1.add("F1");

			List<String> salvoLoc2 = new ArrayList<>();
			salvoLoc2.add("B4");
			salvoLoc2.add("B5");
			salvoLoc1.add("B6");

			List<String> salvoLoc3 = new ArrayList<>();
			salvoLoc3.add("F2");
			salvoLoc3.add("D5");

			List<String> salvoLoc4 = new ArrayList<>();
			salvoLoc2.add("E1");
			salvoLoc2.add("H3");
			salvoLoc1.add("A2");

			Salvo salvoes1= new Salvo(1, salvoLoc1, gamePlayer1);
			Salvo salvoes2= new Salvo(1, salvoLoc2, gamePlayer2);
			Salvo salvoes3= new Salvo(2, salvoLoc3, gamePlayer1);
			Salvo salvoes4= new Salvo(2, salvoLoc4, gamePlayer2);
			Salvo salvoes5= new Salvo(3, salvoLoc1, gamePlayer1);
			Salvo salvoes6= new Salvo(3, salvoLoc4, gamePlayer2);

			salvoRepository.save(salvoes1);
			salvoRepository.save(salvoes2);
			salvoRepository.save(salvoes3);
			salvoRepository.save(salvoes4);
			salvoRepository.save(salvoes5);
			salvoRepository.save(salvoes6);












		};
	}

}

