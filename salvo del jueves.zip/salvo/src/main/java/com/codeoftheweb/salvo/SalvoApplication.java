package com.codeoftheweb.salvo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

import java.util.Date;

@SpringBootApplication
public class SalvoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalvoApplication.class, args);
	}

	@Bean
	public CommandLineRunner initData(PlayerRepository playerRepository, GameRepository gameRepository) {
		return (args) -> {
			// save a couple of customer


			playerRepository.save(new Player("candela.Ayala116@Gmail.com"));
			playerRepository.save(new Player("Maria_Flores@Yahoo.com"));
			playerRepository.save(new Player("Sarita_y_Franco@Hotmail.com"));
			playerRepository.save(new Player("Daniel992@Gmail.com"));
			playerRepository.save(new Player("Michelle_Obama@Gmail.com"));

			Date date = new Date();
			Date date2 = Date.from(date.toInstant().plusSeconds(3600));
			Date date3 = Date.from(date.toInstant().plusSeconds(7200));


			Game game1 = new Game(date);
			game1.setCreationDate(new Date());
			Game game2 = new Game(date2);
			game2.setCreationDate(new Date());
			Game game3 = new Game(date3);
			game3.setCreationDate(new Date());

			gameRepository.save(game1);
			gameRepository.save(game2);
			gameRepository.save(game3);

		};
	}

}

