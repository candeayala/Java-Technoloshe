package com.codeoftheweb.salvo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class SalvoController {

    @Autowired
    private GameRepository gameRepository;

    @Autowired
    private PlayerRepository playerRepository;

    @Autowired
    private ScoreRepository scoreRepository;

    @Autowired
    private GamePlayerRepository gamePlayerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private ShipRepository shipRepository;

    @Autowired
    private SalvoRepository salvoRepository;


    public List<Map<String, Object>> getGames() {
        return gameRepository
                .findAll()
                .stream()
                .map(game -> makeGameDTO(game))
                .collect(Collectors.toList());
    }

    private Map<String, Object> makeGameDTO(Game game) {
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("id", game.getId());
        dto.put("creationDate", game.getCreationDate());
        dto.put("gamePlayers", getGamePlayerList(game.getGamePlayers()));
        dto.put("scores", getScores(game.getGamePlayers()));//getGamePlayers por getScores
        return dto;
    }

    private List<Map<String, Object>> getGamePlayerList(Set<GamePlayer> gamePlayers) {
        {
            return gamePlayers
                    .stream()
                    .map(gamePlayer -> makeGamePlayerDTO(gamePlayer))
                    .collect(Collectors.toList());
        }
    }

    private Map<String, Object> makeGamePlayerDTO(GamePlayer gamePlayer) {
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("id", gamePlayer.getId());
        dto.put("joinDate", gamePlayer.getJoinDate().getTime());
        dto.put("player", makePlayerDTO(gamePlayer.getPlayer()));
        return dto;
    }

    private Map<String, Object> makePlayerDTO(Player player) {
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("id", player.getId());
        dto.put("userName", player.getUserName());
        dto.put("score", player.getScores());
        return dto;
    }

    private Map<String, Object> shipDTO(Ship ship) {
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("shipType", ship.getShipType());
        dto.put("shipLocations", ship.getShipLocations());
        dto.put("player", ship.getGamePlayer().getPlayer().getId());
        return dto;
    }

    private List<Map<String, Object>> getShipList(Set<Ship> ships) {
        return ships
                .stream()
                .map(ship -> shipDTO(ship))
                .collect(Collectors.toList());

    }

    @RequestMapping("/game_view/{gpid}")   //le cambie id por gpid
    public ResponseEntity<Object> cheat(@PathVariable long gpid, Authentication authentication) {
        Player player = getLoggedPlayer(authentication);
        GamePlayer gamePlayer = gamePlayerRepository.findById(gpid).orElse(null);
        if (gamePlayer == null) {
            return new ResponseEntity<>(makeMap("error", "Forbidden"), HttpStatus.FORBIDDEN);
        }

        if (player.getId() != gamePlayer.getPlayer().getId()) {//getPlayer por getPlayers
            return new ResponseEntity<>(makeMap("error", "Unauthorized"), HttpStatus.UNAUTHORIZED);
        }

        //public Map<String, Object> getGameView(@PathVariable long id) {
        //    return gameViewDTO(gamePlayerRepository.findById(id).get()); }

        //private Map<String, Object> gameViewDTO(GamePlayer gamePlayer) {
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("id", gamePlayer.getGame().getId());
        dto.put("created", gamePlayer.getGame().getCreationDate());
        dto.put("gamePlayers", getGamePlayerList((gamePlayer.getGame().getGamePlayers())));
        dto.put("ships", getShipList(gamePlayer.getShips()));
        dto.put("salvoes", getSalvoList(gamePlayer.getGame()));
        dto.put("hits", makeHitsDTO(gamePlayer, gamePlayer.getOpponentGamePlayer()));
        return new ResponseEntity<>(dto, HttpStatus.OK);
    }


    //Create the salvo list for the JSON

    private List<Map<String, Object>> getSalvoList(Game game) {
        List<Map<String, Object>> myList = new ArrayList<>();
        game.getGamePlayers().forEach(gamePlayer -> myList.addAll(makeSalvoList(gamePlayer.getSalvoes())));
        return myList;
    }

    //Create the salvo DTO

    private List<Map<String, Object>> makeSalvoList(Set<Salvo> salvoes) {
        return salvoes
                .stream()
                .map(salvo -> salvoDTO(salvo))
                .collect(Collectors.toList());
    }

    private Map<String, Object> salvoDTO(Salvo salvo) {
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("turn", salvo.getTurn());
        dto.put("player", salvo.getGamePlayer().getPlayer().getId());
        dto.put("salvoLocations", salvo.getSalvoLocations());

        return dto;
    }
    //create the leaderBoard page

    @RequestMapping("/leaderBoard")
    public List<Map<String, Object>> makeLeaderBoard() {
        {
            return playerRepository
                    .findAll()
                    .stream()
                    .map(Player -> makeLeaderBoardDTO(Player))
                    .collect(Collectors.toList());
        }
    }

    private Map<String, Object> scoreDTO(Score score) {
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("score", score.getScore());
        dto.put("player", score.getPlayer());
        dto.put("finishDate", score.getFinishDate());
        dto.put("id", score.getId());

        return dto;
    }


    public List<Map<String, Object>> getScores(Set<GamePlayer> gamePlayers) {

        return gamePlayers
                .stream()
                .map(player -> makeScoreDTO(player))
                .collect(Collectors.toList());

    }

    private Map<String, Object> makeScoreDTO(GamePlayer gamePlayer) {
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("playerID", gamePlayer.getPlayer().getId());
        if (gamePlayer.getScore() != null)
            dto.put("score", gamePlayer.getScore().getScore());

        return dto;
    }

    private Map<String, Object> makeLeaderBoardDTO(Player player) {
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("name", player.getUserName());
        dto.put("total", player.getTotalScore(player));
        dto.put("won", player.getWins(player.getScores()));
        dto.put("lost", player.getLoses(player.getScores()));
        dto.put("tied", player.getDraws(player.getScores()));

        return dto;
    }

    @RequestMapping("/games")
    public Map<String, Object> getPlayer(Authentication authentication) {
        Map<String, Object> dto = new LinkedHashMap<>();
        if
        (authentication == null || authentication instanceof AnonymousAuthenticationToken)
            dto.put("player", "Guest");

        else {
            Player player = playerRepository.findByUserName(authentication.getName());
            dto.put("player", loggedPlayerDTO(player));
        }
        dto.put("games", getGames());
        return dto;
    }

    public Map<String, Object> loggedPlayerDTO(Player player) {
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("id", player.getId());
        dto.put("name", player.getUserName());

        return dto;
    }

    @RequestMapping(path = "/players", method = RequestMethod.POST)
    public ResponseEntity<Object> register(
            @RequestParam String name, @RequestParam String pwd) {

        if (name.isEmpty() || pwd.isEmpty()) {
            return new ResponseEntity<>("Missing data", HttpStatus.FORBIDDEN);
        }

        if (playerRepository.findByUserName(name) != null) {
            return new ResponseEntity<>("Name already in use", HttpStatus.FORBIDDEN);
        }

        playerRepository.save(new Player(name, passwordEncoder.encode(pwd)));
        return new ResponseEntity<>(HttpStatus.CREATED);

    }

    private Map<String, Object> makeMap(String key, Object value) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put(key, value);
        return map;
    }

    Player getLoggedPlayer(Authentication authentication) {
        return playerRepository.findByUserName(authentication.getName());
    }

    //metodo para crear un nuevo jugador

    /*@RequestMapping(path = "/games", method = RequestMethod,POST)
    public ResponseEntity<Map<String,Object>> createGame(Authentication authentication){
        if(authentication.getName().isEmpty()){
            return new ResponseEntity<>(makeMap("error", "Unauthorized"), HttpStatus.UNAUTHORIZED);
        }

        //CREA Y GUARDA UN NUEVO JUEGO
        Game newGame = gameRepository.save(new Game(LocalDateTime.now()));

        //CREA UN NUEVO GAMEPLAYER PARA ESTE JUEGO Y ESTE JUGADOR ACTUAL
        GamePlayer newGamePlayer = gamePlayerRepository.save(new GamePlayer(LocalDateTime.now().newGame, playerRepository));

        //ENVÍA LA RESPONSE CREADA CON JSON CON LA NUEVA GAME PLAYER ID
        return new ResponseEntity<>( makeMap("gpid", newGamePlayer.getId()), HttpStatus.CREATED);
    }*/

    @RequestMapping(path = "/games", method = RequestMethod.POST)
    public ResponseEntity<Object> newGame(Authentication authentication) {
        Map<String, Object> response = new LinkedHashMap<String, Object>();
        if (isGuest(authentication)) {
            response.put("error", "no autenticado");
            return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
        } else {
            Player player = playerRepository.findByUserName(authentication.getName());
            Game game = gameRepository.save(new Game(new Date()));
            GamePlayer gamePlayer = gamePlayerRepository.save(new GamePlayer(game, player, game.getCreationDate()));//(player,game,game.getCreationDate)
            response.put("gpid", gamePlayer.getId());
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        }
    }

    private boolean isGuest(Authentication authentication) {
        Player player = playerRepository.findByUserName(authentication.getName());
        boolean guest = false;
        if (player == null) {
            guest = true;
        }
        return guest;
    }


    @RequestMapping(path = "/game/{nn}/players", method = RequestMethod.POST)
    public ResponseEntity<Object> joinGame(@PathVariable Long nn, Authentication authentication) {
        Map<String, Object> response = new LinkedHashMap<String, Object>();
        if (isGuest(authentication)) {
            response.put("error", "no autenticado");
            return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
        } else {
            Game game = gameRepository.getOne(nn);
            if (game != null) {
                if (game.getGamePlayers().size() < 2) {
                    Player player = playerRepository.findByUserName(authentication.getName());
                    GamePlayer gamePlayer = gamePlayerRepository.save(new GamePlayer(game, player, game.getCreationDate()));
                    response.put("gpid", gamePlayer.getId());
                    return new ResponseEntity<>(response, HttpStatus.CREATED);
                } else {
                    response.put("error", "game is full");
                    return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
                }
            } else {
                response.put("error", "no such game");
                return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
            }
        }
    }

    @RequestMapping(path = "/games/players/{gamePlayerID}/ships", method = RequestMethod.POST)
    public ResponseEntity<Map<String, Object>> addShips(@PathVariable Long gamePlayerID, Authentication authentication, @RequestBody Set<Ship> ships) {
        if (isGuest(authentication)) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);

        GamePlayer gamePlayer = gamePlayerRepository.findById(gamePlayerID).orElse(null);
        Player player = playerRepository.findByUserName(authentication.getName());

        if (gamePlayer == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);

        if (player.getId() != gamePlayer.getPlayer().getId()) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);

        if (gamePlayer.getShips().size() >= 5) return new ResponseEntity<>(HttpStatus.FORBIDDEN);

        for (Ship ship : ships) {
            ship.setGamePlayer(gamePlayer);
            shipRepository.save(ship);
        }

        return new ResponseEntity<>(makeMap("OK", "Ships placed!"), HttpStatus.OK);
    }

    @RequestMapping(path = "/games/players/{gamePlayerID}/salvoes", method = RequestMethod.POST)
    public ResponseEntity<Object> addSalvo(@PathVariable long gamePlayerID, Authentication authentication, @RequestBody Salvo salvo) {
        Map<String, Object> response = new LinkedHashMap<>();

        if (!isGuest(authentication)) {
            GamePlayer gamePlayer = gamePlayerRepository.getOne(gamePlayerID);
            Player player = playerRepository.findByUserName(authentication.getName());

            if (gamePlayer != null) {   //si no es un invitado

                if (gamePlayer.getPlayer().getId() == player.getId()) {   //Si coinciden los players
                    System.out.println("ok coinciden los players.");

                    if (!gamePlayer.isTurnLoaded(salvo.getTurn())) {
                        salvo.setGamePlayer(gamePlayer);
                        salvoRepository.save(salvo);
                        System.out.println("entro el salvo");
                        response.put("Ok", " salvo placed");
                        return new ResponseEntity<>(response, HttpStatus.CREATED);

                    } else {
                        response.put("Error", "User already placed the salvoes on this turn");
                        System.out.println("user already placed the salvoes on this turn");

                        return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);

                    }
                } else {    //Si no coinciden los players
                    response.put("Error", "player do not belong to this game");
                    System.out.println("no coinciden los players");

                    return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);

                }
            }
        }
        return new ResponseEntity<>(makeMap("Ok", "Salvo created!"), HttpStatus.OK);
    }

    private Map<String, Object> makeHitsDTO(GamePlayer selfGP, GamePlayer opponentGP){
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("self", getHits(selfGP, opponentGP));
        dto.put("opponent", getHits(opponentGP, selfGP));
        return dto;
    }

    private List<Map> getHits(GamePlayer gamePlayer, GamePlayer opponentGameplayer) {
        List<Map> hits = new ArrayList<>();
        Integer carrierDamage = 0;
        Integer battleshipDamage = 0;
        Integer submarineDamage = 0;
        Integer destroyerDamage = 0;
        Integer patrolboatDamage = 0;
        List <String> carrierLocation = new ArrayList<>();
        List <String> battleshipLocation = new ArrayList<>();
        List <String> submarineLocation = new ArrayList<>();
        List <String> destroyerLocation = new ArrayList<>();
        List <String> patrolboatLocation = new ArrayList<>();
        gamePlayer.getShips().forEach(ship -> {
            switch (ship.getShipType()) {
                case "carrier":
                    carrierLocation.addAll(ship.getShipLocations());
                    break;
                case "battleship":
                    battleshipLocation.addAll(ship.getShipLocations());
                    break;
                case "submarine":
                    submarineLocation.addAll(ship.getShipLocations());
                    break;
                case "destroyer":
                    destroyerLocation.addAll(ship.getShipLocations());
                    break;
                case "patrolboat":
                    patrolboatLocation.addAll(ship.getShipLocations());
                    break;
            }
        });
        for (Salvo salvo : opponentGameplayer.getSalvoes()) {
            Integer carrierHitsInTurn = 0;
            Integer battleshipHitsInTurn = 0;
            Integer submarineHitsInTurn = 0;
            Integer destroyerHitsInTurn = 0;
            Integer patrolboatHitsInTurn = 0;
            Integer missedShots = salvo.getSalvoLocations().size();
            Map<String, Object> hitsMapPerTurn = new LinkedHashMap<>();
            Map<String, Object> damagesPerTurn = new LinkedHashMap<>();
            List<String> salvoLocationsList = new ArrayList<>();
            List<String> hitCellsList = new ArrayList<>();
            salvoLocationsList.addAll(salvo.getSalvoLocations());
            for (String salvoShot : salvoLocationsList) {
                if (carrierLocation.contains(salvoShot)) {
                    carrierDamage++;
                    carrierHitsInTurn++;
                    hitCellsList.add(salvoShot);
                    missedShots--;
                }
                if (battleshipLocation.contains(salvoShot)) {
                    battleshipDamage++;
                    battleshipHitsInTurn++;
                    hitCellsList.add(salvoShot);
                    missedShots--;
                }
                if (submarineLocation.contains(salvoShot)) {
                    submarineDamage++;
                    submarineHitsInTurn++;
                    hitCellsList.add(salvoShot);
                    missedShots--;
                }
                if (destroyerLocation.contains(salvoShot)) {
                    destroyerDamage++;
                    destroyerHitsInTurn++;
                    hitCellsList.add(salvoShot);
                    missedShots--;
                }
                if (patrolboatLocation.contains(salvoShot)) {
                    patrolboatDamage++;
                    patrolboatHitsInTurn++;
                    hitCellsList.add(salvoShot);
                    missedShots--;
                }
            }
            damagesPerTurn.put("carrierHits", carrierHitsInTurn);
            damagesPerTurn.put("battleshipHits", battleshipHitsInTurn);
            damagesPerTurn.put("submarineHits", submarineHitsInTurn);
            damagesPerTurn.put("destroyerHits", destroyerHitsInTurn);
            damagesPerTurn.put("patrolboatHits", patrolboatHitsInTurn);
            damagesPerTurn.put("carrier", carrierDamage);
            damagesPerTurn.put("battleship", battleshipDamage);
            damagesPerTurn.put("submarine", submarineDamage);
            damagesPerTurn.put("destroyer", destroyerDamage);
            damagesPerTurn.put("patrolboat", patrolboatDamage);
            hitsMapPerTurn.put("turn", salvo.getTurn());
            hitsMapPerTurn.put("hitLocations", hitCellsList);
            hitsMapPerTurn.put("damages", damagesPerTurn);
            hitsMapPerTurn.put("missed", missedShots);
            hits.add(hitsMapPerTurn);
        }
        return hits;
    }




}

